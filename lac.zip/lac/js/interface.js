// Kiểm tra đăng nhập
if (localStorage.getItem("isLoggedIn") !== "true") {
  location.href = "../pages/login.html";
}

// Hiển thị thông báo ngắn
function showMessage(message, type = "success") {
  const msgBox = document.createElement("div");
  msgBox.textContent = message;
  msgBox.style.position = "fixed";
  msgBox.style.top = "20px";
  msgBox.style.right = "20px";
  msgBox.style.padding = "10px 20px";
  msgBox.style.backgroundColor = type === "error" ? "#e74c3c" : "#2ecc71";
  msgBox.style.color = "#fff";
  msgBox.style.borderRadius = "8px";
  msgBox.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
  msgBox.style.zIndex = 1000;
  document.body.appendChild(msgBox);

  setTimeout(() => msgBox.remove(), 3000);
}

// Khai báo biến
let monthData = {};
let currentMonth = "";
let editingCategoryIndex = null;
let categoryToDeleteIndex = null;

// Load dữ liệu từ localStorage
document.addEventListener('DOMContentLoaded', function() {
  if (localStorage.getItem('monthData')) {
    monthData = JSON.parse(localStorage.getItem('monthData'));
  }
});

// Xử lý logout
document.getElementById('embed_logout').addEventListener('change', function(event) {
  if (event.target.value === 'logout') {
    localStorage.removeItem('loggedInUser');
    localStorage.removeItem('isLoggedIn');
    sessionStorage.removeItem('loggedInUser');
    location.href = '../pages/login.html';
  }
});

// Chọn tháng
document.getElementById("month_time").addEventListener("change", function(event) {
  const selectedMonth = event.target.value;

  if (!monthData[selectedMonth]) {
    monthData[selectedMonth] = { budget: 0, categories: [], transactions: [] };
  }

  currentMonth = selectedMonth;
  loadMonthData();
});

// Lưu ngân sách tháng
document.getElementById("save-budget").addEventListener("click", function() {
  if (currentMonth === "") {
    showMessage("Vui lòng chọn tháng trước!", "error");
    return;
  }
  const budgetInput = document.getElementById("Budget_month");
  if (budgetInput.value.trim() === "") {
    showMessage("Vui lòng nhập ngân sách tháng!", "error");
    return;
  }
  monthData[currentMonth].budget = parseInt(budgetInput.value);
  saveData();
  showMessage("Đã lưu ngân sách tháng!");
  updateRemaining();
});

// Thêm danh mục
document.getElementById("add-category").addEventListener("click", function() {
  if (currentMonth === "") {
    showMessage("Vui lòng chọn tháng trước!", "error");
    return;
  }
  const nameInput = document.getElementById("Category_name");
  const limitInput = document.getElementById("limit");
  if (nameInput.value.trim() === "" || limitInput.value.trim() === "") {
    showMessage("Vui lòng nhập đầy đủ!", "error");
    return;
  }
  const category = {
    name: nameInput.value.trim(),
    limit: parseInt(limitInput.value)
  };
  monthData[currentMonth].categories.push(category);
  saveData();
  renderCategories();
  showMessage("Đã thêm danh mục!");
  nameInput.value = "";
  limitInput.value = "";
});

// Render danh mục
function renderCategories() {
  const tableBody = document.querySelector(".box_4 table tbody");
  tableBody.innerHTML = "";
  if (!currentMonth || !monthData[currentMonth]) return;

  monthData[currentMonth].categories.forEach((cat, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${cat.name}</td>
      <td>${cat.limit.toLocaleString()} VND</td>
      <td>
        <a href="#" class="edit-btn" data-index="${index}">Sửa</a> | 
        <a href="#" class="delete-btn" data-index="${index}">Xóa</a>
      </td>
    `;
    tableBody.appendChild(row);
  });

  document.querySelectorAll(".edit-btn").forEach(btn => {
    btn.addEventListener("click", function(e) {
      e.preventDefault();
      editCategory(parseInt(this.dataset.index));
    });
  });

  document.querySelectorAll(".delete-btn").forEach(btn => {
    btn.addEventListener("click", function(e) {
      e.preventDefault();
      deleteCategory(parseInt(this.dataset.index));
    });
  });
}

// Sửa danh mục
function editCategory(index) {
  editingCategoryIndex = index;
  const cat = monthData[currentMonth].categories[index];
  document.getElementById('edit-category-name').value = cat.name;
  document.getElementById('edit-category-limit').value = cat.limit;
  openEditModal();
}

function openEditModal() {
  document.getElementById('editModal').style.display = 'flex';
}

function closeEditModal() {
  document.getElementById('editModal').style.display = 'none';
  editingCategoryIndex = null;
}

function confirmEdit() {
  const nameInput = document.getElementById('edit-category-name').value.trim();
  const limitInput = parseInt(document.getElementById('edit-category-limit').value.trim());

  if (nameInput === "" || isNaN(limitInput)) {
    showMessage("Vui lòng nhập đầy đủ!", "error");
    return;
  }

  if (editingCategoryIndex !== null) {
    monthData[currentMonth].categories[editingCategoryIndex] = {
      name: nameInput,
      limit: limitInput
    };
    saveData();
    renderCategories();
    showMessage("Đã cập nhật danh mục!");
  }

  closeEditModal();
}

// Xóa danh mục
function deleteCategory(index) {
  categoryToDeleteIndex = index;
  openModal();
}

function confirmDelete() {
  if (categoryToDeleteIndex !== null) {
    monthData[currentMonth].categories.splice(categoryToDeleteIndex, 1);
    saveData();
    renderCategories();
    showMessage("Đã xóa danh mục!");
    categoryToDeleteIndex = null;
    closeModal();
  }
}

function openModal() {
  document.getElementById('confirmModal').style.display = 'flex';
}

function closeModal() {
  document.getElementById('confirmModal').style.display = 'none';
  categoryToDeleteIndex = null;
}

// Thêm giao dịch
document.getElementById("add-expense").addEventListener("click", function() {
  if (currentMonth === "") {
    showMessage("Vui lòng chọn tháng trước!", "error");
    return;
  }
  const amountInput = document.getElementById("expense-amount");
  const noteInput = document.getElementById("expense-note");
  if (amountInput.value.trim() === "" || isNaN(amountInput.value)) {
    showMessage("Vui lòng nhập số tiền hợp lệ!", "error");
    return;
  }
  const transaction = {
    amount: parseInt(amountInput.value),
    note: noteInput.value.trim() || "Không có ghi chú",
    date: new Date().toISOString()
  };
  if (!monthData[currentMonth].transactions) {
    monthData[currentMonth].transactions = [];
  }
  monthData[currentMonth].transactions.push(transaction);
  saveData();
  renderTransactions();
  updateRemaining();
  showMessage("Đã thêm giao dịch!");
  amountInput.value = "";
  noteInput.value = "";
});

// Render giao dịch
function renderTransactions() {
  const transactionList = document.querySelector(".transaction-list");
  transactionList.innerHTML = "";
  if (!currentMonth || !monthData[currentMonth] || !monthData[currentMonth].transactions) return;

  monthData[currentMonth].transactions.forEach((trans, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span>${trans.note}</span>
      <span>${trans.amount.toLocaleString()} VND</span>
      <span>${new Date(trans.date).toLocaleDateString()}</span>
    `;
    transactionList.appendChild(li);
  });
}

// Cập nhật số tiền còn lại
function updateRemaining() {
  const p1 = document.querySelector(".box_3 .p1");
  if (currentMonth && monthData[currentMonth]) {
    const spent = monthData[currentMonth].transactions
      ? monthData[currentMonth].transactions.reduce((sum, trans) => sum + trans.amount, 0)
      : 0;
    const remaining = monthData[currentMonth].budget - spent;
    p1.textContent = `${remaining.toLocaleString()} VND`;
  } else {
    p1.textContent = "0 VND";
  }
}

// Load dữ liệu khi chọn tháng
function loadMonthData() {
  if (!monthData[currentMonth]) return;
  document.getElementById("Budget_month").value = monthData[currentMonth].budget || "";
  renderCategories();
  renderTransactions();
  updateRemaining();
}

// Lưu dữ liệu vào localStorage
function saveData() {
  localStorage.setItem('monthData', JSON.stringify(monthData));
}